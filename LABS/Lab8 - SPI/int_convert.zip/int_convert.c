#include <stdio.h>
#define converted_string_length	20
char converted_string[converted_string_length];		//define string containing 20 chars
//converted values must be <= 20 chars or the array will saturate

//this function takes a floating point input value (input) and converts it to a string which is stored in ascii form in the converted_string array
void float2string(float input)
{
snprintf(converted_string, converted_string_length, "%f", input);
}

//this function takes a fixed point input value (input) and converts it to a string which is stored in ascii form in the converted_string array
void int2string(int input)
{
sprintf(converted_string, "%d", input);
}
