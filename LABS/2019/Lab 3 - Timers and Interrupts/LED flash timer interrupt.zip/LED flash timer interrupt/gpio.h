#ifndef __GPIO_H
#define __GPIO_H
#include "stm32f4xx.h"

void Toggle_LED (void);
void Init_LED(void);

#endif
